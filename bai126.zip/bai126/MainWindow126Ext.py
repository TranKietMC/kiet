import sys
import pandas as pd
from PyQt6 import QtWidgets
from MainWindow126 import Ui_MainWindow  # Import giao diện có sẵn


class MainApp(QtWidgets.QMainWindow, Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)

        # Đọc dữ liệu từ file CSV
        self.file_path = "TCB_2018_2020.csv"  # Đặt đúng đường dẫn file
        self.df = pd.read_csv(self.file_path)

        # Kết nối các nút bấm với hàm xử lý
        self.pushButtonFind1.clicked.connect(self.find_close)
        self.pushButtonFind2.clicked.connect(self.find_low)
        self.pushButtonFind3.clicked.connect(self.find_by_date)
        self.pushButtonFind4.clicked.connect(self.find_by_date_list)

    def find_close(self):
        """Lọc dữ liệu có Close < x và Close > y"""
        try:
            x, y = map(float, self.lineEditData.text().split(","))
            result = self.df[(self.df["Close"] < x) | (self.df["Close"] > y)]
            self.label_result1.setText(f"Results:\n{result.to_string(index=False)}")
        except Exception as e:
            self.label_result1.setText(f"Lỗi: {e}")

    def find_low(self):
        """Lọc dữ liệu với Low trong khoảng (x, y)"""
        try:
            x, y = map(float, self.lineEditData_2.text().split(","))
            result = self.df[(self.df["Low"] >= x) & (self.df["Low"] <= y)][["Date", "High", "Low"]]
            self.label__result2.setText(f"Results:\n{result.to_string(index=False)}")
        except Exception as e:
            self.label__result2.setText(f"Lỗi: {e}")

    def find_by_date(self):
        """Lọc dữ liệu theo ngày cụ thể"""
        try:
            date = self.lineEditData_3.text().strip()
            result = self.df[self.df["Date"] == date]
            if result.empty:
                self.label__result3.setText("Không tìm thấy dữ liệu cho ngày này.")
            else:
                self.label__result3.setText(f"Results:\n{result.to_string(index=False)}")
        except Exception as e:
            self.label__result3.setText(f"Lỗi: {e}")

    def find_by_date_list(self):
        """Lọc dữ liệu theo danh sách ngày"""
        try:
            date_list = [d.strip() for d in self.lineEditData_4.text().split(",")]
            result = self.df[self.df["Date"].isin(date_list)]
            if result.empty:
                self.label__result4.setText("Không tìm thấy dữ liệu cho các ngày này.")
            else:
                self.label__result4.setText(f"Results:\n{result.to_string(index=False)}")
        except Exception as e:
            self.label__result4.setText(f"Lỗi: {e}")


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    window = MainApp()
    window.show()
    sys.exit(app.exec())
